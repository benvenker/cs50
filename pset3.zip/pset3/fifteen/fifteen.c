/**
 * fifteen.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Implements the Game of Fifteen (generalized to d x d).
 *
 * Usage: ./fifteen d
 *
 * whereby the board's dimensions are to be d x d,
 * where d must be in [MIN,MAX]
 *
 * Note that usleep is obsolete, but it offers more granularity than
 * sleep and is simpler to use than nanosleep; `man usleep` for more.
 */
 
#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "helpers.h"

// board's minimal dimension
#define MIN 3

// board's maximal dimension
#define MAX 9

// board, whereby board[i][j] represents row i and column j
int board[MAX][MAX];

// board's dimension
int d;

int i, j, count; // 

// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
bool won(void);
void save(void);
void swap(int* x, int* y);


int main(int argc, string argv[])
{
    // greet player
    greet();

    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: ./fifteen d\n");
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    if (d < MIN || d > MAX)
    {
        printf("Board must be between %i x %i and %i x %i, inclusive.\n",
            MIN, MIN, MAX, MAX);
        return 2;
    }

    // initialize the board
    init();

    // accept moves until game is won
    while (true)
    {
        // clear the screen
        clear();

        // draw the current state of the board
        draw();

        // saves the current state of the board (for testing)
        save();

        // check for win
        if (won())
        {
            printf("ftw!\n");
            break;
        }

        // prompt for move
        printf("Tile to move: ");
        int tile = GetInt();

        // move if possible, else report illegality
        if (!move(tile))
        {
            printf("\nIllegal move.\n");
            usleep(500000);
        }

        // sleep for animation's sake
        usleep(500000);
    }

    // that's all folks
    return 0;
}

/**
 * Clears screen using ANSI escape sequences.
 */
void clear(void)
{
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/**
 * Greets player.
 */
void greet(void)
{
    clear();
    printf("GAME OF FIFTEEN\n");
    usleep(2000000);
}

/**
 * Initializes the game's board with tiles numbered 1 through d*d - 1,
 * (i.e., fills board with values but does not actually print them),
 * whereby board[i][j] represents row i and column j.
 */
void init(void)
{ 
    // populate the array with values
    int count = 0;
    
    if (j < d && i < d)    // 
    {
        for (int i = 0; i <= d-1; i++)
        {
            for (int j = 0; j <= d-1; j++)
            {
                board[i][j] = d*d - (count + 1);
                count ++;

                if ( (d*d) % 2 == 0)   // if the number of tile is odd
                {
                    // swap the last two tiles
                    board[d-1][d-2] = 2;                   
                    board[d-1][d-3] = 1;   
                }   
            }
        }
        board[d-1][d-1] = 95;   
    } 
}

/**
 * Prints the board in its current state.
 */
void draw(void)
{ 
    for (int i = 0; i <= d-1; i++)
    {
        for (int j = 0; j <= d-1 ; j++)
        {
          if (board[i][j] == 95) { printf("%2c ", board[i][j]); }
          else
            printf("%2d ", board[i][j]);
        }
        printf("\n");
        printf("\n");
    } 
}

/**
 * If tile borders empty space, moves tile and returns true, else
 * returns false. 
 */
bool move(int tile)
{
/*    int middle, tilePosition;*/
/*    */
/*    middle = board[d/2][0];*/
/*    tilePosition = board[0][0];*/
    
 // TODO get the position of the user's int
    if (tile > 0)
    {   int blankTileRow, blankTileColumn;
              
        // find the blank tile
        for (int i = 0; i <= d-1; i++)
            {
                for (int j = 0; j <= d-1; j++)
                {
                    if (board[i][j] == 95)
                    {
                        blankTileRow = i;
                        blankTileColumn = j;
                    }            
                }
            }         

        for (int i = d-1; i >= 0; i--)
        {   
            for (int j = d-1; j >= 0; j--)
            {               
                if (board[i][j] == tile)    // find the user's tile
                {                      
                    int newRow = (i - blankTileRow);
                    int newCol = (j - blankTileColumn);
                    
                    // move up and down
                    if (j == blankTileColumn)
                    {
                        if (newRow == 1 || newRow == -1)
                        {
                            swap(&i, &blankTileRow);
/*                            int temp = i;*/
/*                            i = blankTileRow;*/
/*                            blankTileRow = temp;*/
                        }
                    }
                    
                    // move right and left
                    else if (i == blankTileRow) 
                    {
                        if (newCol == 1 || newCol == -1)
                        {    
                            swap(&j, &blankTileColumn);
/*                            int temp = j;*/
/*                            j = blankTileColumn;*/
/*                            blankTileColumn = temp;*/
                        }
                    }
                    
                    board[blankTileRow][blankTileColumn] = 95;  // new blank tile position
                    board[i][j] = tile; // tile's new location

                    return true;
                }        
            }     
        }
    }  
    return false;
}                 

/**
 * Returns true if game is won (i.e., board is in winning configuration), 
 * else false.
 */
bool won(void)
{
   // int  leftNum = board[i][j], rightNum = board[i][j+1];
    
    int number = 0;
    
    for (int i = 0; i <= d-1; i++)
            {
                for (int j = 0; j <= d-1; j++)
                {               
                    if ((i+j) == (d*2 - 2) && (number != 95))
                    {
                        return true;
                    }
                        
                    if (number > board[i][j])               
                    {
                        return false;
                    }
                    number = board[i][j];                                                         
                }
               
            }
             return true; 
           
/*    return false;*/
}

/**
 * Saves the current state of the board to disk (for testing).
 */
void save(void)
{
    // log
    const string log = "log.txt";

    // delete existing log, if any, before first save
    static bool saved = false;
    if (!saved)
    {
        unlink(log);
        saved = true;
    }

    // open log
    FILE* p = fopen(log, "a");
    if (p == NULL)
    {
        return;
    }

    // log board
    fprintf(p, "{");
    for (int i = 0; i < d; i++)
    {
        fprintf(p, "{");
        for (int j = 0; j < d; j++)
        {
            fprintf(p, "%i", board[i][j]);
            if (j < d - 1)
            {
                fprintf(p, ",");
            }
        }
        fprintf(p, "}");
        if (i < d - 1)
        {
            fprintf(p, ",");
        }
    }
    fprintf(p, "}\n");

    // close log
    fclose(p);
}

/*/**/
/** Swaps the values of a pair of ints.*/
/**/

void swap(int* a, int* b )
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
